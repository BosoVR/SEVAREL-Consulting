# SEVAREL Consulting · Workshop-Vorbereitung

## Ziel
Die Gruppe soll am Ende folgende Frage beantworten:
Nicht Teil des Workshops:
Erwartetes Ergebnisdokument:

## Personen
Auftraggeber und Entscheidung:
Kenntnis des heutigen Ablaufs:
Spaetere Anwender:
Technische Perspektive:
Weitere benoetigte Fachkompetenz:

## Vorabmaterial
Kurze Beschreibung der Ausgangslage:
Zwei typische und ein schwieriger Fall:
Bekannte Rahmenbedingungen:
Offene Fragen:

## Beispielhafte Arbeitsagenda
1. Gemeinsames Verstaendnis der Frage.
2. Ist-Situation und abweichende Perspektiven.
3. Geeignete Optionen sammeln.
4. Bewertung anhand vereinbarter Kriterien.
5. Entscheidungen und offene Punkte trennen.
6. Verantwortliche und naechste Schritte festhalten.

## Nachbereitung
Protokollverantwortung:
Rueckmeldefrist:
Offene Entscheidung / zustaendige Person / Termin:
Zusatzauftrag erforderlich? Ja / Nein / Offen

Die Agenda wird an die konkrete Aufgabe angepasst. Ein Workshop ist nicht automatisch ein Auftrag zur anschliessenden Umsetzung.
