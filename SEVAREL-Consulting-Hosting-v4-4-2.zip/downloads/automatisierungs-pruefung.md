# Automatisierungs-Prüfung

SEVAREL Consulting · Arbeitsvorlage · Stand 17. September 2026

Auslöser, Regeln, Fehlerwege und Betriebsverantwortung prüfen.
Auszufüllen mit freigegebenen Informationen. Leere Felder bleiben offen; keine Daten oder Freigaben erfinden.

## Aufgabe
Gewünschte Veränderung: 
Heutiger Ablauf: 
Eindeutiger Auslöser: 
Erkennbarer Abschluss: 
Fachlicher Verantwortlicher: 

## Voraussetzungen
- [ ] Regeln für Normalfälle beschrieben.
- [ ] Ausnahmewege definiert.
- [ ] Datenherkunft, führendes System und Bearbeitungsrechte geklärt.
- [ ] Zulässige Schnittstelle technisch geprüft.
- [ ] Wiederholung und Dublette unterschieden.
- [ ] Fehlerzustand, Benachrichtigung und zuständige Rolle festgelegt.
- [ ] Kontrollierter Rückfallweg vorhanden.
- [ ] Kosten und reale Netto-Kapazität separat betrachtet.

## Tests
| Fall | Eingang | Erwartung | Nachweis | Urteil | Zuständig |
|---|---|---|---|---|---|
| Normal | | | | | |
| Dublette | | | | | |
| Pflichtfeld fehlt | | | | | |
| Berechtigung fehlt | | | | | |
| Zielsystem ausgefallen | | | | | |

## Entscheidung
Automatisieren / erst Grundlagen klären / nicht weiterverfolgen: 
Begründung: 
Begrenzter Pilotumfang: 
Stop-Kriterien: 

## Herkunft und Freigabe
Verwendete Quellen: 
Annahmen: 
Offene Fragen: 
Fachlich geprüft durch / Datum: 

Diese Vorlage beschreibt ein Arbeitsmodell. Sie ersetzt keine technische, rechtliche oder fachliche Prüfung des konkreten Vorhabens.
