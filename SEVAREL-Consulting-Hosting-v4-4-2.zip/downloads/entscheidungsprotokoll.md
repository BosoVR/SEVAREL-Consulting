# SEVAREL Consulting · Entscheidungsprotokoll

Datum / Version:
Entscheidungsfrage:
Entscheidungsverantwortliche Person:
Beteiligte Rollen:

## Ausgangslage
Belegte Tatsachen:
Schaetzungen:
Offene Fragen:

## Optionen
Option A:
Option B:
Bestehenden Zustand beibehalten / verbessern:

## Bewertung
Kriterien:
Muss-Kriterien:
Kostenannahmen und Laufzeit:
Risiken und Abhaengigkeiten:
Moegliche wirtschaftliche Eigeninteressen:

## Entscheidung
Gewaehlte Option:
Begruendung:
Bewusst akzeptierte Nachteile:
Voraussetzungen vor der Umsetzung:
Wann muss neu entschieden werden?

## Naechste Schritte
Aufgabe / Person / Termin / Nachweis:

Beratungsergebnis, technische Umsetzung und unabhaengige Pruefung werden getrennt beauftragt und nicht miteinander verwechselt.
