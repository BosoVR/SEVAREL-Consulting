# Programme auswählen & Nutzung verbessern

Arbeitsvorlage · SEVAREL Consulting · Stand 2026-09-18

## Auftrag
Unternehmen: ___
Verantwortliche Person: ___
Entscheidungsfrage: ___
Termin / Rollen: ___

## Vorbereitung
- [ ] Problemstellung und betrachtete Softwarekategorie.
- [ ] Vorhandene Kandidaten, sofern bereits bekannt.
- [ ] Kritische Prozesse, bestehende Schnittstellen und Rollen.
- [ ] Budget- und Zeitrahmen sowie unverzichtbare Einschränkungen.

## Agenda
| Minuten | Arbeitsblock | Ergebnis |
|---|---|---|
| 30 | Auswahlauftrag | Ziel, Betrachtungsraum und Entscheidungsträger festlegen. |
| 60 | Kriterien | Muss-Kriterien von gewichtbaren Anforderungen trennen. |
| 60 | Demofälle | Typische Arbeit, Ausnahme und Berechtigung mit derselben Prüfanweisung beschreiben. |
| 50 | Bewertung und Kosten | Skala, Gewichtung, Belege und Kostenhorizont vereinbaren. |
| 40 | Nächste Schritte | Zuständigkeiten, Anbieterfragen und Termin der Entscheidung vorbereiten. |

## Übung
Zwei synthetische Angebote erhalten unterschiedliche Stärken und unterschiedliche Nachweislücken. Die Gruppe trennt eine im Test beobachtete Fähigkeit von einer Aussage auf einem Produktblatt. Anschließend werden die Gewichte leicht verändert. Wechselt dadurch die Empfehlung, muss das Ergebnis als empfindlich gegenüber den Annahmen kenntlich bleiben.

## Ergebnisse
- [ ] Versionierte Kriterienmatrix mit begründeter Gewichtung.
- [ ] Drehbuch für vergleichbare Demos.
- [ ] Vorlage zur Erfassung von Belegen, offenen Fragen und Kosten.
- [ ] Ein abgestimmter nächster Auswahl- und Entscheidungsablauf.

## Beschlüsse und Übergabe
| Entscheidung / offene Frage | Beleg / Annahme | Verantwortlich | Termin |
|---|---|---|---|
| ___ | ___ | ___ | ___ |

## Grenzen
Keine vollständige Marktrecherche und kein verbindlicher Sieger für ungeprüfte Software. Rechtliche Vertragsprüfung und technisch tiefe Sicherheitsbewertung benötigen einen eigenen Auftrag und passende Fachkompetenz.

Nur freigegebene oder bereinigte Daten verwenden. Keine Zugangsdaten eintragen.
