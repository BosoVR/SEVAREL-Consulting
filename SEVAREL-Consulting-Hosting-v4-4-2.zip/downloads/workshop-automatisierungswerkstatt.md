# Automatisierung & Schnittstellen planen

Arbeitsvorlage · SEVAREL Consulting · Stand 2026-09-18

## Auftrag
Unternehmen: ___
Verantwortliche Person: ___
Entscheidungsfrage: ___
Termin / Rollen: ___

## Vorbereitung
- [ ] Ein konkreter Vorgang mit Auslöser und gewünschtem Ergebnis.
- [ ] Beteiligte Programme, bekannte Schnittstellen und verantwortliche Rollen.
- [ ] Bereinigte Normal-, Doppel- und Fehlerfälle.
- [ ] Bekannte Grenzen zu Zugriffen, Lizenzen und Datenweitergabe.

## Agenda
| Minuten | Arbeitsblock | Ergebnis |
|---|---|---|
| 30 | Vorgang eingrenzen | Anfang, Ende und gewünschtes Ergebnis vereinbaren. |
| 60 | Ist-Datenfluss | Programme, Quellen und manuelle Übertragungen aufnehmen. |
| 60 | Regeln oder KI | Eindeutige Regeln von variablen Inhalten und Prüfaufgaben trennen. |
| 90 | Schnittstellen und Ausnahmewege | Feldzuordnung, doppelte Ereignisse, Fehler und Freigaben entwerfen. |
| 75 | Testbare erste Etappe | Umsetzungspaket und erwartete Testnachweise beschreiben. |
| 45 | Übergabe vorbereiten | Offene API-Prüfungen, Zuständigkeiten und nächste Entscheidung festhalten. |

## Übung
Eine Formularanfrage soll in einer Kundenanwendung erfasst und zur Bearbeitung zugewiesen werden. Die Gruppe untersucht, was bei einem doppelten Eingang, fehlenden Kontaktdaten und einem nicht erreichbaren Zielsystem passieren muss. Erst danach wird entschieden, ob eine KI beim Einordnen des Freitexts einen sinnvollen Zusatznutzen hat.

## Ergebnisse
- [ ] Datenflussbild mit Systemen und führenden Informationen.
- [ ] Beschreibung von Auslösern, Regeln und erlaubten Aktionen.
- [ ] Fehler- und Wiederholungsfälle mit verantwortlichen Rollen.
- [ ] Abgegrenzter technischer Auftrag mit Abnahmekriterien.

## Beschlüsse und Übergabe
| Entscheidung / offene Frage | Beleg / Annahme | Verantwortlich | Termin |
|---|---|---|---|
| ___ | ___ | ___ | ___ |

## Grenzen
Es entsteht ein überprüfbarer Konzeptstand, keine live geschaltete Integration. Technische API-Tests, Umsetzung und Betrieb werden bei Bedarf gesondert vereinbart.

Nur freigegebene oder bereinigte Daten verwenden. Keine Zugangsdaten eintragen.
