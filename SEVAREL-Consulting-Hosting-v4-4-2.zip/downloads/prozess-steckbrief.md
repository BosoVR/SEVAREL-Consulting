# SEVAREL Consulting · Prozess-Steckbrief

Arbeitsvorlage. Kein abgeschlossener Beratungsauftrag und kein validierter Reifegradtest.

## Auftrag
Prozessname:
Entscheidungsfrage:
Fachlich verantwortliche Person:
Stand / Version / Freigabe:

## Grenzen
Anfang des Vorgangs:
Ende des Vorgangs:
Betrachtete Fallarten:
Nicht betrachtete Aufgaben:

## Ausgangslage
Fallzahl und Zeitraum:
Datenquelle der Fallzahl:
Aktive Bearbeitungszeit / Schätzung oder Messung:
Liege- und Wartezeiten:
Nacharbeit und Rückfragen:

## Ablauf
Schritt | Rolle | Eingang | Tätigkeit | Ergebnis | Übergabe | Ausnahme
--- | --- | --- | --- | --- | --- | ---
1 | | | | | |
2 | | | | | |
3 | | | | | |

## Systeme und Daten
Welche Anwendung ist maßgeblich?
Welche Daten werden benötigt?
Wer darf lesen, ändern und freigeben?
Welche Schnittstellen sind tatsächlich vorhanden?

## Verbesserungsoptionen
Organisatorische Änderung:
Bessere Nutzung vorhandener Software:
Standardsoftware oder Erweiterung:
Individuelle Entwicklung als gesonderte Option:
Annahmen und Gegenargumente:

## Prüfung und Entscheidung
Vergleichsmaßstab:
Testfälle einschließlich Ausnahmen:
Erfolgskriterium:
Stop-Kriterium:
Entscheidungsverantwortung:
Nächste Schritte / Person / Termin:

Keine Passwörter, unnötigen personenbezogenen Daten oder vertraulichen Kundendetails in eine ungesicherte Kopie aufnehmen.
