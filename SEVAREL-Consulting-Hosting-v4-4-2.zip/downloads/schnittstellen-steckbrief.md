# Schnittstellen-Steckbrief

SEVAREL Consulting · KI, Software und Technologie · Stand 18. September 2026

Ausfüllbare Arbeitsvorlage. Kein Rechtsgutachten, Zertifikat oder bereits erbrachter Projektnachweis. Nur freigegebene Informationen verwenden, keine Passwörter oder API-Schlüssel eintragen.

## Auftrag

- Vorgang, Zweck und erwartetes Ergebnis: ___
- Auslöser und fachliches Ende: ___
- Quellsystem / Zielsystem / Verantwortliche: ___

## Datenvertrag

- Führendes System je Information: ___
- Feldzuordnung und Bedeutung: ___
- Pflichtfelder, Formate und zulässige Werte: ___
- Identität eines fachlichen Vorgangs: ___
- Zugelassene Quelle und Empfänger: ___

## Technischer Zugang

- Bestätigte API und Version / Quelle / Prüftag: ___
- Tarif und Nutzungsgrenzen: ___
- Authentifizierungsverfahren, keine Geheimnisse eintragen: ___
- Lese- und Schreibrechte: ___
- Freigegebene Testumgebung: ___

## Normal- und Fehlerfälle

- Normalfall / erwartetes Zielergebnis: ___
- Doppelter Eingang / erwartete Wirkung: ___
- Ausfall vor Verarbeitung: ___
- Ausfall nach Verarbeitung ohne Bestätigung: ___
- Fehlende oder ungültige Daten: ___
- KI-Ausgabe außerhalb des Schemas: ___
- Bearbeitung, Eskalation und begrenzte Wiederholungen: ___

## Freigabe und Betrieb

- Abnahmetests und Belege: ___
- Freigebende Fachrolle / IT: ___
- Überwachung, Aktualisierung und Rückfallweg: ___
- Offene Punkte mit Verantwortlichen und Termin: ___

## Quellen und offene Annahmen

| Aussage | Beleg / Datei / Version | Geprüft von | Offen bis |
|---|---|---|---|
| ___ | ___ | ___ | ___ |
