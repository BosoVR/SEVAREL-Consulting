# Prompting & Ergebnisprüfung

Arbeitsvorlage · SEVAREL Consulting · Stand 2026-09-18

## Auftrag
Unternehmen: ___
Verantwortliche Person: ___
Entscheidungsfrage: ___
Termin / Rollen: ___

## Vorbereitung
- [ ] Eine oder zwei Aufgabenarten aus dem eigenen Team.
- [ ] Synthetische oder ausdrücklich freigegebene Beispielinformationen.
- [ ] Kriterien für eine brauchbare Ausgabe und bekannte Fehlerbilder.
- [ ] Freigegebenes Arbeitswerkzeug oder gemeinsame Demonstration abstimmen.

## Agenda
| Minuten | Arbeitsblock | Ergebnis |
|---|---|---|
| 25 | Auftrag statt Schlagwort | Ziel, Nutzer, Eingaben und Grenzen formulieren. |
| 40 | Erste Arbeitsvorlage | Quellen und gewünschte Ausgabe in einen kompakten Auftrag übersetzen. |
| 45 | Fehlerwerkstatt | Unvollständige Informationen, Widerspruch und erfundene Angaben erkennen. |
| 45 | Wiederverwendung | Vorlage an zwei Varianten derselben Aufgabe testen und verbessern. |
| 25 | Freigabe und Übergabe | Prüfliste, Verantwortlichen und zulässige Einsatzgrenzen festhalten. |

## Übung
Eine KI soll aus einer Besprechungsnotiz ein Maßnahmenprotokoll erstellen. Einige Verantwortliche und Termine fehlen absichtlich. Die Vorlage muss diese Lücken sichtbar lassen und darf keine Personen oder Fristen erfinden. Anschließend wird ein Widerspruch eingebaut: Ein Beschluss und eine spätere Korrektur sind nicht gleichberechtigt als gültige Entscheidung zu übernehmen.

## Ergebnisse
- [ ] Ein oder zwei kontextbezogene Prompt-Vorlagen pro vereinbartem Aufgabentyp.
- [ ] Prüfkriterien und Beispielausgaben mit markierten Schwächen.
- [ ] Eine kurze Arbeitsanweisung für Eingabe, Prüfung und Freigabe.
- [ ] Liste der Fälle, die manuell oder fachlich eskaliert werden sollen.

## Beschlüsse und Übergabe
| Entscheidung / offene Frage | Beleg / Annahme | Verantwortlich | Termin |
|---|---|---|---|
| ___ | ___ | ___ | ___ |

## Grenzen
Ein guter Prompt garantiert keine richtige Ausgabe. Die fachliche Prüfung bleibt notwendig. Tool-Abonnements, Produktivzugänge und systemweite Integrationen sind nicht Teil des Lernformats.

Nur freigegebene oder bereinigte Daten verwenden. Keine Zugangsdaten eintragen.
