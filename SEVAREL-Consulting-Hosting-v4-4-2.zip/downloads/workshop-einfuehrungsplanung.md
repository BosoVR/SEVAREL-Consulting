# KI & Software kontrolliert einführen

Arbeitsvorlage · SEVAREL Consulting · Stand 2026-09-18

## Auftrag
Unternehmen: ___
Verantwortliche Person: ___
Entscheidungsfrage: ___
Termin / Rollen: ___

## Vorbereitung
- [ ] Vorhandenes Konzept und vereinbarter Projektumfang.
- [ ] Geplanter Startkorridor und bekannte Abhängigkeiten.
- [ ] Betroffene Nutzergruppen und verfügbare Unterstützung.
- [ ] Offene Fehler, Datenfragen und bisherige Testergebnisse.

## Agenda
| Minuten | Arbeitsblock | Ergebnis |
|---|---|---|
| 30 | Startbild | Ziel, Umfang und tatsächlichen Fertigstellungsstand abgleichen. |
| 50 | Menschen und Rollen | Betroffene Arbeit, Verantwortlichkeit und Qualifizierungsbedarf klären. |
| 60 | Pilot und Freigabe | Erprobung, Akzeptanzkriterien und Stop-Regeln festlegen. |
| 60 | Übergang und Betrieb | Kommunikation, Support, Rückfallweg und Übergabe planen. |
| 40 | Entscheidungspaket | Offene Bedingungen, Verantwortliche und nächsten Beschluss zusammenführen. |

## Übung
Ein synthetisches Projekt ist technisch weitgehend fertig, aber Vertretung, Datenbereinigung und Support sind ungeklärt. Die Gruppe entscheidet, ob ein begrenzter Pilot möglich ist, welche Nutzer teilnehmen dürfen und welche Voraussetzungen einen breiten Start blockieren. Eine fehlende Freigabe wird nicht durch eine positive Statusampel ersetzt.

## Ergebnisse
- [ ] Einführungsplan mit Etappen und Abhängigkeiten.
- [ ] Rollenbezogener Kommunikations- und Qualifizierungsplan.
- [ ] Checkliste für Pilot, Startfreigabe und Übergabe.
- [ ] Offene-Punkte-Liste mit Verantwortlichen und Entscheidungsbedarf.

## Beschlüsse und Übergabe
| Entscheidung / offene Frage | Beleg / Annahme | Verantwortlich | Termin |
|---|---|---|---|
| ___ | ___ | ___ | ___ |

## Grenzen
Kein 24/7-Betriebsdienst, keine technische Fehlerbehebung im Workshop und keine automatische formelle Abnahme von Lieferleistungen. Zuständige Entscheider bleiben ausdrücklich benannt.

Nur freigegebene oder bereinigte Daten verwenden. Keine Zugangsdaten eintragen.
