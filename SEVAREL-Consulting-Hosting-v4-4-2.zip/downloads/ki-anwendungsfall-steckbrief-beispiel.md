# KI-Anwendungsfall-Steckbrief – Ausfüllbeispiel

**Synthetisches Beispiel – keine Kundenreferenz oder Freigabe.**

## Aufgabe
Freigegebene interne Wissensstellen für das fiktive Unternehmen Atelier Nord finden und als belegten Auszug anzeigen.

## Nutzer und betroffene Personen
Simulierte Rollen Mitarbeitende und Teamleitung. Keine echten Mitarbeiterkonten oder personenbezogenen Daten.

## Bisheriger Vergleichsweg
Der einfache Vergleich liefert den ersten thematischen Treffer, ohne Versions- und Rollenfilter.

## Erwarteter Nutzen
Veraltete oder widersprüchliche Informationen erkennen. Eine reale Zeitersparnis wurde nicht gemessen.

## Freigegebene Daten / Quellen
11 synthetische Dokumente Q-01-alt bis Q-09 aus lab-fixtures.json. Der gesamte Bestand ist öffentliches Demomaterial.

## Datenverantwortlicher
Im Beispiel: Fachverantwortung Wissensbestand. Für reale Daten ist vor jedem Pilot eine konkrete Person zu benennen.

## Erlaubtes Ausgabeformat
Wörtlicher Quellenauszug mit Kennung und Version; alternativ Rückfrage, Nicht-Antwort oder Hinweis auf Widerspruch.

## Nicht zulässige Ergänzungen oder Aktionen
Keine erfundenen Angaben und keine Buchung, Freigabe oder Änderung in einem Fremdsystem.

## Zugriffsgrenzen
Q-06 ist nur der simulierten Teamleitung zugeordnet. Das Browsermodell ist kein Zugriffsschutz: Alle Quellen sind öffentlich.

## Normalfälle
T01 Störung melden; T04 Daten für KI-Werkzeuge; T11 Dienstreise. Erwartet wird der Auszug der definierten Quelle.

## Grenzfälle
T03 alte Version; T08 Rolle ohne passende Quelle; T10 widersprüchliche Wartungszeiten; T13 mehrere Themen.

## Kritische Fehler
Falsche Quelle zitieren, veraltete Informationen als aktuell ausgeben oder Widersprüche ohne Rückfrage auflösen.

## Wer kann das Ergebnis fachlich bewerten?
Im realen Pilot eine benannte Fachrolle. Hier erfolgt nur ein automatisierter Soll-Ist-Vergleich, keine Kundenfreigabe.

## Wann muss das System keine Antwort geben?
Keine aktive passende Quelle, ungültige Rolle, widersprüchliche Quellen oder eine Frage außerhalb des Themenbestands.

## Passendere einfache Alternative
Eine gepflegte FAQ oder eine Suche mit verständlichen Filtern. Für feste Textauszüge ist ein Sprachmodell nicht zwingend.

## Technische Machbarkeit
Das Regelmodell ist lokal ausführbar. Semantische Suche, Sprachmodell, Anmeldung und Produktivbetrieb sind nicht umgesetzt.

## Offene Datenschutz-/Sicherheitsfragen
Welche Originalquellen sind zulässig? Wer verwaltet Rechte? Wo werden Anfragen verarbeitet? Was darf protokolliert werden?

## Geschätzte einmalige und laufende Kosten
Nur synthetische Planungsangabe Q-06: 2.400 Euro netto Obergrenze. Kein SEVAREL-Angebot und keine reale Kostenschätzung.

## Freigegebenes Testwerkzeug
Mitgeliefertes JavaScript-Regelmodell und Node-Testlauf; keine Modell-API und keine externen Konten.

## Weiter / klären / verwerfen
Klären. Das Demoergebnis rechtfertigt keinen Produktivstart.

## Begründung
20 von 20 vorbereiteten Regeltests entsprechen den Erwartungen. Sprachverständnis und serverseitige Rechte sind damit nicht geprüft.

## Nächster Verantwortlicher
Für ein reales Vorhaben benennt der Auftraggeber Fachverantwortung und IT vor der Planung eines Piloten.

## Verwendete Quellen
lab-fixtures.json, lab.js und praxislabor-testprotokoll.json. Alle Unternehmensangaben sind fiktiv.

## Annahmen
Die Testfälle wurden für die Demonstrationsregeln erstellt. Kein unabhängiger oder repräsentativer Benchmark.

## Offene Fragen
Wie reagiert ein echtes Modell auf neue Fragen, geänderte Quellen und Angriffe? Welche Qualität wäre fachlich ausreichend?

## Fachlich geprüft durch / Datum
Keine persönliche oder rechtliche Freigabe. Technischer Demonstrationsstand: 18.09.2026.

