# Rollen & Übergaben

SEVAREL Consulting · Arbeitsvorlage · Stand 17. September 2026

Verantwortung, Vertretung und Entscheidungspunkte klären.
Auszufüllen mit freigegebenen Informationen. Leere Felder bleiben offen; keine Daten oder Freigaben erfinden.

## Kontext
Prozess oder Projekt: 
Ziel: 

| Schritt / Entscheidung | Ausführende Rolle | Entscheider | Mitwirkung | Vertretung | Eingangsbedingung | Ergebnis |
|---|---|---|---|---|---|---|
| | | | | | | |

## Eskalation
Auslöser: 
Empfänger: 
Benötigte Informationen: 
Vereinbarter Zeitrahmen: 

## Prüfung
- [ ] Keine Entscheidung ohne benannte Befugnis.
- [ ] Vertretung ist praktisch verfügbar.
- [ ] Ergebnis einer Übergabe ist erkennbar.
- [ ] Unklare Rollen sind vor Start als offene Voraussetzung markiert.

## Herkunft und Freigabe
Verwendete Quellen: 
Annahmen: 
Offene Fragen: 
Fachlich geprüft durch / Datum: 

Diese Vorlage beschreibt ein Arbeitsmodell. Sie ersetzt keine technische, rechtliche oder fachliche Prüfung des konkreten Vorhabens.
