# Fachlich-technisches Abnahmeprotokoll

SEVAREL Consulting · KI, Software und Technologie · Stand 18. September 2026

Ausfüllbare Arbeitsvorlage. Kein Rechtsgutachten, Zertifikat oder bereits erbrachter Projektnachweis. Nur freigegebene Informationen verwenden, keine Passwörter oder API-Schlüssel eintragen.

## Gegenstand

- Projekt / Etappe / Version / Datum: ___
- Vereinbarter Umfang und erwartete Ergebnisse: ___
- Testumgebung / freigegebene Daten: ___

## Nachweise

- Normalfall mit Erwartung und Beobachtung: ___
- Grenz- und Fehlerfall: ___
- Rollen- und Berechtigungsfall: ___
- Export / Wiederherstellung / Rückfallweg: ___
- Bei KI: fachliche Ergebnisqualität, Quellen und Kontrollaufwand: ___

## Abweichungen

- Fehler innerhalb des Umfangs: ___
- Neue Anforderung, gesondert zu bewerten: ___
- Bekannte Grenzen und akzeptierte Restpunkte: ___
- Keine Nachweise vorhanden für: ___

## Entscheidung

- Ergebnis: angenommen / unter Bedingungen / nicht angenommen
- Begründung und erforderliche Korrekturen: ___
- Freigebende Person / Rolle / Datum: ___
- Betriebsverantwortung und Supportweg: ___
- Nachprüfung / Termin / verantwortlich: ___

## Quellen und offene Annahmen

| Aussage | Beleg / Datei / Version | Geprüft von | Offen bis |
|---|---|---|---|
| ___ | ___ | ___ | ___ |
