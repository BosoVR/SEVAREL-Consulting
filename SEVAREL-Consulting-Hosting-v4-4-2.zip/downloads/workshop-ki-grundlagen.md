# KI-Grundlagen für Teams

Arbeitsvorlage · SEVAREL Consulting · Stand 2026-09-18

## Auftrag
Unternehmen: ___
Verantwortliche Person: ___
Entscheidungsfrage: ___
Termin / Rollen: ___

## Vorbereitung
- [ ] Rollen, Vorkenntnisse und typische Aufgaben der Teilnehmer benennen.
- [ ] Freigegebene Werkzeuge und interne Nutzungsregeln mitteilen, sofern vorhanden.
- [ ] Keine vertraulichen Dokumente oder Zugangsdaten mitbringen.
- [ ] Abstimmen, ob gemeinsam demonstriert oder mit eigenen freigegebenen Zugängen gearbeitet wird.

## Agenda
| Minuten | Arbeitsblock | Ergebnis |
|---|---|---|
| 35 | Grundprinzipien | Generative Ergebnisse, Kontext, Quellen und Grenzen ohne Produkt-Hype einordnen. |
| 40 | Aufgabenwahl | Entwurf, Zusammenfassung und Suche von verbindlicher Entscheidung unterscheiden. |
| 60 | Praktische Übung | Eine Arbeitsaufgabe beschreiben, Ergebnis prüfen und begründet überarbeiten. |
| 45 | Fehler und Daten | Erfundene Angaben, ungeprüfte Quellen und unzulässige Eingaben erkennen. |
| 35 | Nutzungsregeln | Erlaubte Aufgaben, Freigabewege und Rückfragen für den eigenen Kontext festhalten. |
| 25 | Transfer | Individuelle Anwendung, Lernfragen und nächste Übung vereinbaren. |

## Übung
Die Teilnehmer erhalten einen synthetischen, absichtlich unvollständigen Vorgang. Die KI soll einen Entwurf erstellen, aber fehlende Daten markieren. Anschließend wird geprüft, ob Fakten ergänzt wurden, die nicht in der Vorlage stehen. Der Lernerfolg liegt darin, Fehler zu erkennen und eine begründete Freigabeentscheidung zu treffen — nicht nur einen flüssigen Text zu erzeugen.

## Ergebnisse
- [ ] Kontextbezogene Übersicht geeigneter und ungeeigneter Aufgaben.
- [ ] Ausgearbeitete Übungsbeispiele und eine Prüfliste für Ergebnisse.
- [ ] Entwurf praktischer Nutzungsregeln zur internen Freigabe.
- [ ] Dokumentation der behandelten Inhalte und auf Vereinbarung der Teilnahme.

## Beschlüsse und Übergabe
| Entscheidung / offene Frage | Beleg / Annahme | Verantwortlich | Termin |
|---|---|---|---|
| ___ | ___ | ___ | ___ |

## Grenzen
Keine allgemeine Rechtsberatung, keine externe Zertifizierung und keine pauschale Zusage zur Erfüllung aller AI-Act-Pflichten. Die konkrete organisatorische Einordnung und Freigabe bleiben beim verantwortlichen Unternehmen.

Nur freigegebene oder bereinigte Daten verwenden. Keine Zugangsdaten eintragen.
