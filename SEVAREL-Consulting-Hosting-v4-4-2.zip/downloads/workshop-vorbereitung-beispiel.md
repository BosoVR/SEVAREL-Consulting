# Workshop-Vorbereitung – Ausfüllbeispiel

**Synthetisches Beispiel – keine Kundenreferenz oder Freigabe.**

## Die Gruppe soll am Ende folgende Frage beantworten
Welche Voraussetzungen fehlen, bevor das Beispielunternehmen einen internen KI-Wissensassistenten erproben sollte?

## Nicht Teil des Workshops
Kein Modellkauf, keine Produktivinstallation, keine echten Personal- oder Kundendaten und keine rechtliche Freigabe.

## Erwartetes Ergebnisdokument
Priorisierte Klärungsliste mit Quellenverantwortung, Testanforderungen und Entscheidung zur weiteren Vorbereitung.

## Auftraggeber und Entscheidung
Im Szenario eine noch zu benennende fachlich verantwortliche Person mit Entscheidungsbefugnis.

## Kenntnis des heutigen Ablaufs
Eine Rolle, die typische Suchfragen und heutige Schwierigkeiten erklären kann.

## Spätere Anwender
Zwei Personen aus dem betroffenen Bereich; Teilnahme im realen Auftrag zu bestätigen.

## Technische Perspektive
IT-Rolle für Identitäten, Quellenanbindung, Betrieb und Datenexport.

## Weitere benötigte Fachkompetenz
Bei Bedarf zuständige Rollen für Datenfreigabe, Datenschutz und Sicherheitsbewertung.

## Kurze Beschreibung der Ausgangslage
Der öffentliche Demobestand enthält aktive, aufgehobene und widersprüchliche Informationen. Nur synthetisches Material.

## Zwei typische und ein schwieriger Fall
Normal: Störung melden. Normal: neue Programme freigeben. Schwierig: zwei widersprüchliche Wartungsfenster.

## Bekannte Rahmenbedingungen
Lokaler Browser und mitgelieferte Unterlagen. Keine Modell-API, personenbezogenen Daten oder externen Zugriffe.

## Offene Fragen
Welche Fragen sind wichtig? Wer pflegt Quellen? Welche Fehler verhindern eine Freigabe? Wie werden neue Fragen getestet?

## Protokollverantwortung
Vor Termin zu benennen; niemand wird im Beispiel als tatsächlich verpflichtet dargestellt.

## Rückmeldefrist
Im Angebot festzulegen. Für dieses Ausfüllbeispiel gibt es keinen echten Termin.

## Offene Entscheidung / zuständige Person / Termin
Datenumfang und technische Verantwortung klären / Auftraggeber benennt Rollen / Termin offen.

## Zusatzauftrag erforderlich? Ja / Nein / Offen
Offen. Eine Pilotvorbereitung oder technische Umsetzung wird durch den Workshop nicht automatisch beauftragt.

