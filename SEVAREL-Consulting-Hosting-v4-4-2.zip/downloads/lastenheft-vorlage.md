# Lastenheft-Vorlage

SEVAREL Consulting · Arbeitsvorlage · Stand 17. September 2026

Ziele, Rollen, Anforderungen und Akzeptanzfälle strukturiert dokumentieren.
Auszufüllen mit freigegebenen Informationen. Leere Felder bleiben offen; keine Daten oder Freigaben erfinden.

## 1. Auftrag
Projekt / Version / Datum: 
Auftraggeber und Entscheider: 
Problem und gewünschtes Ergebnis: 
Betrachtungsraum und Nicht-Ziele: 

## 2. Nutzeraufgaben
| Rolle | Aufgabe | Eingabe | Erwünschtes Ergebnis | Sonderfall |
|---|---|---|---|---|
| | | | | |

## 3. Anforderungen
| ID | Anforderung | Zweck | Muss / Soll | Quelle | Offen / freigegeben |
|---|---|---|---|---|---|
| ANF-001 | | | | | |

## 4. Daten und Schnittstellen
Führende Datenquellen: 
Berechtigte Rollen: 
Datenrichtung / Felder / Auslöser: 
Fehler- und Wiederholungsverhalten: 
Betriebs- und Gerätebedingungen: 

## 5. Akzeptanzfälle
| Test-ID | Anforderung | Ausgangslage | Aktion | Erwartetes Ergebnis | Prüfer |
|---|---|---|---|---|---|
| T-001 | ANF-001 | | | | |

## 6. Lieferung und Betrieb
Vereinbarte Liefergegenstände: 
Nicht enthaltene Leistungen: 
Zugänge und Mitwirkung: 
Support / Übergabe: 

## 7. Offene Fragen und Änderungen
| ID | Frage / Änderung | Auswirkung | Verantwortlich | Freigabe |
|---|---|---|---|---|
| | | | | |

## Herkunft und Freigabe
Verwendete Quellen: 
Annahmen: 
Offene Fragen: 
Fachlich geprüft durch / Datum: 

Diese Vorlage beschreibt ein Arbeitsmodell. Sie ersetzt keine technische, rechtliche oder fachliche Prüfung des konkreten Vorhabens.
