# KI-Fahrplan

SEVAREL Consulting · KI, Software und Technologie · Stand 18. September 2026

Ausfüllbare Arbeitsvorlage. Kein Rechtsgutachten, Zertifikat oder bereits erbrachter Projektnachweis. Nur freigegebene Informationen verwenden, keine Passwörter oder API-Schlüssel eintragen.

## Ziel

- Betrachteter Bereich und anstehende Entscheidung: ___
- Konkrete Aufgaben und gewünschte Verbesserung: ___
- Bestehende Anwendungen und geprüfte Alternativen ohne KI: ___

## Anwendungsfälle

- Fall-ID / Aufgabe / Daten / Nutzer: ___
- Nutzenhypothese und heutiger Vergleichsmaßstab: ___
- Fehlerfolgen, Qualitätsgrenzen und zuständige Prüfung: ___
- Noch unbestätigte Voraussetzung: ___

## Prioritäten

- Als Nächstes prüfen — Grund: ___
- Zurückstellen — Grund und Wiederaufnahmebedingung: ___
- Nicht verfolgen — Grund: ___

## Erste Etappe

- Pilotfrage und zugelassener Testumfang: ___
- Verantwortliche für Daten, Qualität, Technik und Entscheidung: ___
- Kostenrahmen und tatsächliche Angebote: ___
- Weiter-, Nachbesserungs- und Stoppkriterien: ___
- Nächste Entscheidung / Termin: ___

## Quellen und offene Annahmen

| Aussage | Beleg / Datei / Version | Geprüft von | Offen bis |
|---|---|---|---|
| ___ | ___ | ___ | ___ |
