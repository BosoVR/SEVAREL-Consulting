# KI-Wissensassistent konzipieren

Arbeitsvorlage · SEVAREL Consulting · Stand 2026-09-18

## Auftrag
Unternehmen: ___
Verantwortliche Person: ___
Entscheidungsfrage: ___
Termin / Rollen: ___

## Vorbereitung
- [ ] Beispiele typischer Fragen und der heute verwendeten Quellen.
- [ ] Übersicht der Dokumentverantwortlichen und relevanten Nutzerrollen.
- [ ] Bereinigte Beispiele aktueller, veralteter und widersprüchlicher Informationen.
- [ ] Geklärte Teilnahme von Fachbereich und IT; keine unkontrollierten Produktivzugriffe.

## Agenda
| Minuten | Arbeitsblock | Ergebnis |
|---|---|---|
| 30 | Aufgabe abgrenzen | Nutzer, Fragen und nicht erlaubte Auskünfte festlegen. |
| 60 | Quellen und Verantwortung | Aktualität, Freigabe und Rollen den Wissensquellen zuordnen. |
| 75 | Antwort- und Suchkonzept | Benötigte Belege, Quellenanzeige und Verhalten bei fehlendem Wissen entwerfen. |
| 75 | Grenz- und Rechtefälle | Rollenwechsel, fremde Anweisungen und unzulässige Fragen als Tests formulieren. |
| 75 | Pilot und Betriebsrahmen | Testmenge, Qualitätskriterien, Aktualisierung und Fehlerweg bestimmen. |
| 45 | Entscheidungen sichern | Voraussetzungen und nächste technische Prüfaufgaben festhalten. |

## Übung
Die Teilnehmer bearbeiten dieselbe Frage einmal mit aktuellen freigegebenen Unterlagen, einmal mit einer veralteten Fassung und einmal ohne zugelassene Quelle. Sie legen fest, wann der Assistent belegen, nachfragen oder die Antwort verweigern soll. Eine zweite Rolle besitzt weniger Rechte; ihr Ergebnis darf nicht einfach die Informationen der ersten Rolle übernehmen.

## Ergebnisse
- [ ] Abgegrenztes Assistenzszenario mit Nutzer- und Quellenrollen.
- [ ] Quelleninventar mit Freigabe und Aktualisierungsverantwortung.
- [ ] Testkatalog für Antworten, Nicht-Antworten und Berechtigungen.
- [ ] Pilotauftrag mit Qualitäts- und Betriebsfragen.

## Beschlüsse und Übergabe
| Entscheidung / offene Frage | Beleg / Annahme | Verantwortlich | Termin |
|---|---|---|---|
| ___ | ___ | ___ | ___ |

## Grenzen
Der Workshop liefert das vereinbarte Konzept. Er baut keinen produktiven Wissensassistenten und ersetzt weder eine Rechteprüfung im Zielsystem noch einen technischen Sicherheitstest.

Nur freigegebene oder bereinigte Daten verwenden. Keine Zugangsdaten eintragen.
