# Prozess-Messplan

SEVAREL Consulting · Arbeitsvorlage · Stand 17. September 2026

Messgrenzen, Datenquellen und Vergleichsbedingungen offenlegen.
Auszufüllen mit freigegebenen Informationen. Leere Felder bleiben offen; keine Daten oder Freigaben erfinden.

## Untersuchungsauftrag
Prozess: 
Verbesserungsfrage: 
Startzustand: 
Abschlusszustand: 
Betrachtete Varianten: 
Verantwortlich: 

## Kennzahlen
| Kennzahl | Zähler | Nenner / Zeitgrenze | Einheit | Datenquelle | Rhythmus | Prüfer |
|---|---|---|---|---|---|---|
| Durchlaufzeit | | | Stunden | | | |
| Bearbeitungszeit | | | Minuten | | | |
| Rückfragenquote | | | Prozent | | | |
| Erstabschlussqualität | | | Prozent | | | |

## Vergleichbarkeit
Vorher-Zeitraum / Fallzahl: 
Nachher-Zeitraum / Fallzahl: 
Ausschlüsse und Gründe: 
Veränderte Zusammensetzung: 
Zusätzlicher Kontrollaufwand: 
Datenqualität / Unsicherheit: 

## Ergebnis
Beobachtung: 
Interpretation (gesondert): 
Alternative Erklärung: 
Nächste begrenzte Maßnahme: 
Freigabe: 

## Herkunft und Freigabe
Verwendete Quellen: 
Annahmen: 
Offene Fragen: 
Fachlich geprüft durch / Datum: 

Diese Vorlage beschreibt ein Arbeitsmodell. Sie ersetzt keine technische, rechtliche oder fachliche Prüfung des konkreten Vorhabens.
