# Einführungs-Checkliste

SEVAREL Consulting · Arbeitsvorlage · Stand 17. September 2026

Pilot, Startbedingungen, Schulung und Betriebsübergabe abstimmen.
Auszufüllen mit freigegebenen Informationen. Leere Felder bleiben offen; keine Daten oder Freigaben erfinden.

## Ziel und Umfang
Veränderung: 
Betroffene Rollen / Standorte: 
Geplanter Startkorridor: 
Nicht-Ziele: 
Entscheider: 

## Startbedingungen
- [ ] Fachtests nachvollziehbar durchgeführt.
- [ ] Kritische Fehler abgegrenzt und behandelt.
- [ ] Daten und Rechte geklärt.
- [ ] Nutzer rollenbezogen vorbereitet.
- [ ] Hilfen und Ansprechpartner erreichbar.
- [ ] Rückfallweg beschrieben und prüfbar.
- [ ] Offene Punkte eingeordnet: akzeptiert / nacharbeiten / startblockierend.

## Aufgaben
| Aufgabe | Rolle | Termin | Abhängigkeit | Nachweis |
|---|---|---|---|---|
| | | | | |

## Startentscheidung
Pilot / begrenzter Start / vollständiger Start / Stopp: 
Grundlage: 
Nicht geprüfte Bedingungen: 
Freigabe durch: 

## Betriebsübergabe
Verantwortlich für Betrieb: 
Supportweg: 
Bekannte Einschränkungen: 
Restaufgaben: 
Reviewdatum: 

## Herkunft und Freigabe
Verwendete Quellen: 
Annahmen: 
Offene Fragen: 
Fachlich geprüft durch / Datum: 

Diese Vorlage beschreibt ein Arbeitsmodell. Sie ersetzt keine technische, rechtliche oder fachliche Prüfung des konkreten Vorhabens.
