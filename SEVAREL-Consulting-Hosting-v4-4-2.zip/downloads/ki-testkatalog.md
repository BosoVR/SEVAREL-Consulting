# KI-Testkatalog

SEVAREL Consulting · Arbeitsvorlage · Stand 17. September 2026

Fachliche Kriterien, Vergleichsbasis und Stop-Fälle für einen Piloten.
Auszufüllen mit freigegebenen Informationen. Leere Felder bleiben offen; keine Daten oder Freigaben erfinden.

## Testkontext
Aufgabe und Nutzerkreis: 
Version / Modell / Systemstand: 
Quellenstand: 
Vergleichsverfahren: 
Datenfreigabe: 

## Fälle
| ID | Typ | Eingabe / Quelle | Erwartung | Kritischer Fehler | Ergebnis | Prüfer |
|---|---|---|---|---|---|---|
| KI-01 | Normalfall | | | | | |
| KI-02 | Fehlende Information | | Unsicherheit sichtbar | Erfundene Angabe | | |
| KI-03 | Widerspruch | | Konflikt melden | Falsche Eindeutigkeit | | |
| KI-04 | Berechtigung | | Zugriff verweigern | Offenlegung | | |
| KI-05 | Ausfall | | Kontrollierter Fehlerweg | Doppelte Aktion | | |

## Bewertungsrahmen
Fachliche Richtigkeit: 
Vollständigkeit: 
Zusätzliche Prüf- und Korrekturzeit: 
Kosten: 
Stop-Kriterien: 

## Entscheidung
Bestanden / nachbessern / stoppen / nicht geprüft: 
Begründung: 
Gültigkeitsgrenzen: 
Freigabe: 
Regressionstest für spätere Änderungen: 

## Herkunft und Freigabe
Verwendete Quellen: 
Annahmen: 
Offene Fragen: 
Fachlich geprüft durch / Datum: 

Diese Vorlage beschreibt ein Arbeitsmodell. Sie ersetzt keine technische, rechtliche oder fachliche Prüfung des konkreten Vorhabens.
