# KI-Nutzungsregeln — technische Arbeitsgrundlage

SEVAREL Consulting · KI, Software und Technologie · Stand 18. September 2026

Ausfüllbare Arbeitsvorlage. Kein Rechtsgutachten, Zertifikat oder bereits erbrachter Projektnachweis. Nur freigegebene Informationen verwenden, keine Passwörter oder API-Schlüssel eintragen.

## Geltungsbereich

- Unternehmen / Team / verantwortliche Rolle: ___
- Freigegebene Anwendungen, Versionen und Einsatzzwecke: ___
- Nicht behandelte Fälle und benötigte fachliche Prüfung: ___

## Daten

- Zulässige Datenarten und konkrete Beispiele: ___
- Nur nach Freigabe zulässige Inhalte: ___
- Ausgeschlossene Daten: ___
- Verantwortliche für Bereinigung, Zugang und Aufbewahrung: ___

## Ergebnisse und Aktionen

- Interne Entwürfe: erforderliche Prüfung: ___
- Externe Verwendung: erforderliche Freigabe: ___
- Handelnde Agenten: erlaubte Werkzeuge und Grenzen: ___
- Nicht erlaubte Aktionen / manuelle Bestätigung: ___
- Rückfragen bei fehlenden Quellen oder Unsicherheit: ___

## Technische Kontrollen

- Rollen und Berechtigungen tatsächlich eingerichtet: ___
- Protokolle ohne unnötige sensible Inhalte: ___
- Abschalt- und Eskalationsweg: ___
- Tests für unzulässige Anfragen / Rechtefälle: ___

## Einführung

- Schulung und Praxisfälle: ___
- Ansprechpartner und Meldeweg: ___
- Fachliche und erforderliche rechtliche Freigaben: ___
- Prüftermin sowie Änderungsanlässe: ___

## Quellen und offene Annahmen

| Aussage | Beleg / Datei / Version | Geprüft von | Offen bis |
|---|---|---|---|
| ___ | ___ | ___ | ___ |
