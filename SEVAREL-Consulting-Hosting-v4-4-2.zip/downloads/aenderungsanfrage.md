# Änderungsanfrage

SEVAREL Consulting · Arbeitsvorlage · Stand 17. September 2026

Neue Wünsche von Fehlern und ursprünglich vereinbarten Ergebnissen trennen.
Auszufüllen mit freigegebenen Informationen. Leere Felder bleiben offen; keine Daten oder Freigaben erfinden.

## Anlass
Projekt / bestehender Umfang / Version: 
Anfragende Person: 
Gewünschte Änderung: 
Begründung: 

## Einordnung
Fehler innerhalb des vereinbarten Umfangs / neue Anforderung / offene Klärung: 
Betroffene Anforderungen und Tests: 

## Auswirkung
Zusätzlicher Nutzen: 
Zeit- und Kostenannahmen: 
Abhängigkeiten und Risiken: 
Betroffene Liefergegenstände: 
Alternative: 

## Entscheidung
Jetzt / später / ablehnen / weiter klären: 
Freigabe durch: 
Datum: 
Aktualisierter Umfang: 

## Herkunft und Freigabe
Verwendete Quellen: 
Annahmen: 
Offene Fragen: 
Fachlich geprüft durch / Datum: 

Diese Vorlage beschreibt ein Arbeitsmodell. Sie ersetzt keine technische, rechtliche oder fachliche Prüfung des konkreten Vorhabens.
