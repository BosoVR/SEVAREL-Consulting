# KI-Orientierung für Entscheider

Arbeitsvorlage · SEVAREL Consulting · Stand 2026-09-18

## Auftrag
Unternehmen: ___
Verantwortliche Person: ___
Entscheidungsfrage: ___
Termin / Rollen: ___

## Vorbereitung
- [ ] Zwei bis drei konkrete geschäftliche Aufgaben und gewünschte Verbesserungen.
- [ ] Übersicht bereits genutzter Programme und KI-Anwendungen.
- [ ] Bekannte Grenzen zu Daten, Ressourcen und Entscheidungszuständigkeiten.
- [ ] Teilnahme einer Person mit Entscheidungsmandat.

## Agenda
| Minuten | Arbeitsblock | Ergebnis |
|---|---|---|
| 30 | Auftrag und Erwartungen | Die zu treffende Entscheidung und den Betrachtungsraum festhalten. |
| 60 | KI im technischen Zusammenhang | Fertige Anwendungen, Modelle, Integration und Grenzen an Beispielen unterscheiden. |
| 75 | Mögliche Einsatzfelder | Konkrete Arbeitsfälle sammeln und gegen Alternativen ohne KI abgrenzen. |
| 75 | Voraussetzungen prüfen | Daten, Prüfbarkeit, Nutzerrollen, Kosten und offene Risiken zuordnen. |
| 75 | Prioritäten und Pilotrahmen | Geeignete Fälle sowie bewusst zurückgestellte Ideen begründen. |
| 45 | Entscheidungen und Prüfaufträge | Zuständigkeiten, nächste Schritte und Freigaben dokumentieren. |

## Übung
Die Gruppe stellt eine interne Wissenssuche, eine KI-gestützte Dokumentensichtung und eine vorhandene Software-Suchfunktion gegenüber. Für jede Option müssen Nutzer, benötigte Quellen, erwartete Qualität und die Verantwortung bei Fehlern benannt werden. Anschließend wird begründet, welche Annahme zuerst getestet werden sollte. Das ist ein methodisches Beispiel, keine Aussage über bereits erzielte Kundenergebnisse.

## Ergebnisse
- [ ] Abgestimmtes Zielbild für den KI-Einsatz im betrachteten Bereich.
- [ ] Priorisierte Anwendungsfälle mit begründeter Auswahl.
- [ ] Liste offener Daten-, Qualitäts- und Betriebsfragen.
- [ ] Beschlossener Prüfauftrag für den nächsten Schritt.

## Beschlüsse und Übergabe
| Entscheidung / offene Frage | Beleg / Annahme | Verantwortlich | Termin |
|---|---|---|---|
| ___ | ___ | ___ | ___ |

## Grenzen
Das Format schafft Orientierung und einen priorisierten Prüfauftrag. Eine vollständige technische Machbarkeitsstudie, verbindliche Projektpreise und rechtliche Freigaben sind nicht automatisch enthalten.

Nur freigegebene oder bereinigte Daten verwenden. Keine Zugangsdaten eintragen.
