# Entscheidungsprotokoll – Ausfüllbeispiel

**Synthetisches Beispiel – keine Kundenreferenz oder Freigabe.**

## Datum / Version
18.09.2026 / synthetisches Beispiel 1.0

## Entscheidungsfrage
Welcher nächste Schritt ist für einen internen Wissensassistenten gerechtfertigt?

## Entscheidungsverantwortliche Person
Im Beispielszenario die fachlich verantwortliche Projektrolle; keine tatsächliche Kundenentscheidung.

## Beteiligte Rollen
Fachverantwortung, IT und spätere Anwender. Reale Namen und Verfügbarkeiten sind offen.

## Belegte Tatsachen
Der lokale Prüflauf erfüllt 20 definierte Erwartungen im Regelmodell. Ein Sprachmodell wurde nicht eingesetzt.

## Schätzungen
Für einen späteren KI-Pilot liegen noch keine realen Aufwands- oder Verbrauchsmessungen vor.

## Offene Fragen
Originalquellen, Rechteverwaltung, Umgebung, Qualitätsmaßstab und Aufwand eines realen Piloten.

## Option A
Vorhandene FAQ und Suche verbessern. Vorteil: geringe technische Änderung. Grenze: keine freie Antwortsynthese.

## Option B
Einen quellengestützten KI-Pilot mit vereinbarten Bewertungsfällen vorbereiten. Betrieb und Modell noch auszuwählen.

## Bestehenden Zustand beibehalten / verbessern
Einträge bereinigen, aufgehobene Fassungen kennzeichnen und Widersprüche auflösen. Das bleibt für Option B erforderlich.

## Kriterien
Belegbarkeit, fachliche Richtigkeit, Aktualität, Datenumgang, Bedienbarkeit, Nacharbeit und Betriebsaufwand.

## Muss-Kriterien
Kein Produktivstart vor Daten- und Zugriffsfreigabe. Quellen müssen prüfbar sein. Ein Nicht-Antwort-Fall ist vorzusehen.

## Kostenannahmen und Laufzeit
Kein Anbieterpreis liegt vor. Zunächst begrenzte Pilotvorbereitung; Umsetzungskosten erst danach ermitteln.

## Risiken und Abhängigkeiten
Schlechte Quellen, fehlende Zuständigkeiten, Modellfehler und nicht ausreichend geprüfte Berechtigungen.

## Mögliche wirtschaftliche Eigeninteressen
Mögliche Vergütung späterer Beratung oder Umsetzung wird bei der Angebotsprüfung transparent berücksichtigt.

## Gewählte Option
Im konstruierten Beispiel: zuerst Quellenpflege, dann Entscheidung über eine abgegrenzte Pilotvorbereitung.

## Begründung
Ein funktionierender Demonstrator ist kein ausreichender Nachweis für sicheren oder wirtschaftlichen Produktivbetrieb.

## Bewusst akzeptierte Nachteile
Eine freie KI-Antwortfunktion wird nicht sofort eingeführt. Vorbereitungsarbeit verzögert die Erprobung mit realen Nutzern.

## Voraussetzungen vor der Umsetzung
Quellenzuständigkeit, zulässige Daten, technische Verantwortung und ein freigegebener Testplan.

## Wann muss neu entschieden werden?
Nach Klärung der Quellen und Bewertung sowie bei wesentlichen Änderungen von Anforderungen oder Betriebsbedingungen.

## Aufgabe / Person / Termin / Nachweis
Quellenliste bereinigen / Fachrolle offen / Termin zu vereinbaren / versioniertes Inventar. Danach Pilotumfang abstimmen / Auftraggeber / Termin offen / schriftlicher Prüfplan.

