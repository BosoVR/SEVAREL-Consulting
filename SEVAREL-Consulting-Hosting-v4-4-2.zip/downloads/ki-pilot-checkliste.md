# SEVAREL Consulting · KI-Pilot-Checkliste

Diese Vorlage bereitet eine fachliche Erprobung vor. Sie ist keine Rechtsfreigabe und keine Bescheinigung zur KI-Compliance.

## 1. Aufgabe und Nutzenhypothese
- Welches konkrete Ergebnis soll entstehen?
- Wer nutzt es, wer prueft es?
- Wie funktioniert die Aufgabe heute?
- Welche Alternative ohne KI wird betrachtet?
- Welcher Nutzen wird vermutet und auf welcher Annahme beruht er?

## 2. Daten und Aktionen
- Welche Quellen sind erforderlich und freigegeben?
- Welche Rollen duerfen welche Inhalte erhalten?
- Welche Aktionen sind verboten?
- Welche Aktionen benoetigen eine menschliche Freigabe?
- Wie werden fehlende oder widerspruechliche Angaben behandelt?

## 3. Testmenge
- Typische Faelle und erwartete Ergebnisse.
- Schwierige, unvollstaendige und unzulaessige Faelle.
- Zugriffstests je Rolle.
- Wiederholte Tests, um schwankende Antworten zu erkennen.
- Menschliche Bewertung mit klar definierten Kategorien.

## 4. Betrieb und Kosten
- Modell- und Anbieterannahmen.
- Tatsachliche Nutzung, variable Kosten und Kontrolle.
- Fehleranzeige und zustaendige Person.
- Rueckfallweg bei Nichtverfuegbarkeit.
- Geplante Aenderungen und erneute Testpflicht.

## 5. Entscheidung
Weiterfuehren, begrenzt einfuehren, ueberarbeiten oder stoppen:
Begruendung:
Offene Risiken:
Fachliche Freigabe / Datum:

Ein guter Einzelfall oder die Zustimmung eines weiteren Modells ersetzt keine dokumentierte fachliche Bewertung.
