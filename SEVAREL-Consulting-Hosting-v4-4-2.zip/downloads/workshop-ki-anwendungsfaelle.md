# KI-Anwendungsfälle & Pilotdesign

Arbeitsvorlage · SEVAREL Consulting · Stand 2026-09-18

## Auftrag
Unternehmen: ___
Verantwortliche Person: ___
Entscheidungsfrage: ___
Termin / Rollen: ___

## Vorbereitung
- [ ] Zwei bis fünf konkrete Aufgaben statt allgemeiner Modellwünsche.
- [ ] Beschreibung der heutigen Bearbeitung und ihrer Schwierigkeiten.
- [ ] Informationen zur Datenherkunft und möglichen Freigaben.
- [ ] Fachperson, die gute und schlechte Ergebnisse tatsächlich unterscheiden kann.

## Agenda
| Minuten | Arbeitsblock | Ergebnis |
|---|---|---|
| 30 | Auswahlrahmen | Ziel, Budgetrahmen und unzulässige Einsatzbedingungen klären. |
| 60 | Anwendungsfälle | Eingabe, Ausgabe, Nutzer und Fehlfolgen je Idee beschreiben. |
| 75 | Vergleich | Nutzen, Voraussetzungen und einfachere Alternativen prüfen. |
| 90 | Pilotauftrag | Kandidat, Datenumfang, Rollen und erlaubte Aktionen definieren. |
| 75 | Prüffälle | Normalfälle, Grenzfälle und kritische Fehler mit Stop-Regeln ausarbeiten. |
| 30 | Freigabeweg | Offene Voraussetzungen, Verantwortliche und nächsten Entscheidungszeitpunkt vereinbaren. |

## Übung
Eine Wissensassistenz wird mit einem normalen Informationswunsch, einer Frage ohne Quelle und einem nicht berechtigten Zugriff getestet — zunächst als Papierprüfung des Pilotdesigns. Die Gruppe beschreibt jeweils, was die spätere technische Lösung tun und ausdrücklich nicht tun darf. So entstehen prüfbare Anforderungen statt der Behauptung, ein Chatbot sei schon durch eine funktionierende Demo geeignet.

## Ergebnisse
- [ ] Bewertete Anwendungsfall-Steckbriefe.
- [ ] Begründete Auswahl oder begründete Nicht-Auswahl eines Piloten.
- [ ] Pilot-Canvas mit Daten, Rollen, Kostenannahmen und Kontrollgrenzen.
- [ ] Testfallkatalog mit fachlichen Akzeptanz- und Stop-Kriterien.

## Beschlüsse und Übergabe
| Entscheidung / offene Frage | Beleg / Annahme | Verantwortlich | Termin |
|---|---|---|---|
| ___ | ___ | ___ | ___ |

## Grenzen
Kein fertig entwickelter Pilot im Workshop und keine Verfügbarkeitsgarantie für bestimmte Anbieter oder Modelle. Der Zugriff auf echte Daten beginnt erst nach den erforderlichen Freigaben.

Nur freigegebene oder bereinigte Daten verwenden. Keine Zugangsdaten eintragen.
