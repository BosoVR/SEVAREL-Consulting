(()=>{'use strict';
const money=n=>new Intl.NumberFormat('de-DE',{style:'currency',currency:'EUR',maximumFractionDigits:0}).format(n),number=n=>new Intl.NumberFormat('de-DE',{maximumFractionDigits:1}).format(n);
let cleanup=()=>{};
function download(text,name,type='text/plain;charset=utf-8'){const blob=new Blob([text],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);}
function init(){cleanup();window.NovaGalaxy?.menu(false);window.NovaGalaxy?.init();const controller=new AbortController();let disposeContact=()=>{};cleanup=()=>{disposeContact();controller.abort();};
 const on=(el,event,fn)=>el?.addEventListener(event,fn,{signal:controller.signal});
 window.NovaLab?.mount(on);
 const trigger=document.querySelector('.menu-trigger'),dialog=document.querySelector('.nav-dialog');
 function close(){if(dialog?.open)dialog.close();document.body.classList.remove('menu-open');trigger?.setAttribute('aria-expanded','false');trigger?.setAttribute('aria-label','Menü öffnen');window.NovaGalaxy?.menu(false);}
 on(trigger,'click',()=>{if(!dialog)return;if(dialog.open){close();return;}dialog.showModal();trigger.setAttribute('aria-expanded','true');trigger.setAttribute('aria-label','Menü schließen');document.body.classList.add('menu-open');window.NovaGalaxy?.menu(true);dialog.querySelector('[data-close-menu]')?.focus();});
 on(dialog,'close',()=>{close();if(trigger?.isConnected)trigger.focus({preventScroll:true});});
 on(dialog,'cancel',e=>{e.preventDefault();close();});
 dialog?.querySelectorAll('[data-close-menu]').forEach(button=>on(button,'click',close));
 dialog?.querySelectorAll('a').forEach(a=>on(a,'click',close));
 const workshopFilter=document.getElementById('workshop-filter');
 on(workshopFilter,'change',()=>{let count=0;document.querySelectorAll('[data-workshop-category]').forEach(item=>{item.hidden=!!workshopFilter.value&&item.dataset.workshopCategory!==workshopFilter.value;if(!item.hidden)count++;});document.getElementById('workshop-count').textContent=count+' '+(count===1?'passendes Format':'passende Formate');});
 document.querySelectorAll('a[href^="#"]:not([href^="#/"])').forEach(a=>on(a,'click',e=>{const id=a.getAttribute('href').slice(1),el=document.getElementById(id);if(!el)return;e.preventDefault();el.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});if(id==='inhalt')el.focus({preventScroll:true});}));
 const search=document.getElementById('knowledge-search'),category=document.getElementById('knowledge-category');
 const filterKnowledge=()=>{if(!search)return;const query=search.value.trim().toLocaleLowerCase('de'),terms=query.split(/\s+/).filter(Boolean);let count=0;document.querySelectorAll('[data-search-item]').forEach(item=>{item.hidden=!terms.every(t=>item.dataset.search.includes(t))||!!category?.value&&item.dataset.category!==category.value;if(!item.hidden)count++;});document.getElementById('search-count').textContent=`${count} ${count===1?'passender Leitfaden':'passende Leitfäden'}`;document.getElementById('search-empty').hidden=count!==0;};
 on(search,'input',filterKnowledge);on(category,'change',filterKnowledge);

 const resourceForm=document.getElementById('resource-search-form');
 if(resourceForm){
   const query=document.getElementById('resource-search'),category=document.getElementById('resource-category');
   const normalize=s=>s.toLocaleLowerCase('de').normalize('NFD').replace(/[\u0300-\u036f]/g,'');
   const filterResources=()=>{
     const terms=normalize(query.value.trim()).split(/\s+/).filter(Boolean);let count=0;
     document.querySelectorAll('[data-resource-item]').forEach(item=>{
       const matches=terms.every(t=>normalize(item.dataset.resourceSearch).includes(t))&&(!category.value||item.dataset.resourceCategory===category.value);
       item.hidden=!matches;if(matches)count++;
     });
     document.getElementById('resource-count').textContent=count+' Arbeitsmittel · jeweils als PDF und Word';
     document.getElementById('resource-empty').hidden=count!==0;
   };
   on(query,'input',filterResources);on(category,'change',filterResources);
   on(resourceForm,'submit',e=>{e.preventDefault();filterResources();});
   on(resourceForm,'reset',e=>{e.preventDefault();query.value='';category.value='';filterResources();});filterResources();
 }
 const calculator=document.getElementById('calculator');
 if(calculator){
   const output=document.getElementById('calc-result'),error=document.getElementById('calc-error');let result=null;
   function stale(){
     result=null;error.textContent='';output.replaceChildren();
     const h=document.createElement('h2');h.textContent='Eingaben geändert.';
     const p=document.createElement('p');p.textContent='Bitte neu berechnen. Das vorherige Ergebnis und sein Export sind nicht mehr aktuell.';output.append(h,p);
   }
   const draw=()=>{
     try{
       const inputs=Object.fromEntries(new FormData(calculator));
       result=NovaTools.potential(inputs);const snapshot=result;error.textContent='';output.replaceChildren();
       const h=document.createElement('h2');h.textContent='Ihr Rechenergebnis.';output.append(h);
       for(const [value,label]of [[`${number(result.hours)} Stunden`,'Mögliche Netto-Kapazität pro Monat'],[money(result.capacityValue),'Kalkulatorischer Kapazitätswert pro Monat'],[money(result.netValue),'Nach laufenden Zusatzkosten pro Monat'],[result.payback===null?'Kein positiver Rücklauf':`${number(result.payback)} Monate`,'Rechnerischer Kapazitäts-Rücklauf, keine Liquiditätsamortisation']]){
         const p=document.createElement('p');p.className='result-metric';const strong=document.createElement('strong'),span=document.createElement('span');strong.textContent=value;span.textContent=label;p.append(strong,span);output.append(p);
       }
       const note=document.createElement('p');note.className='small';note.textContent=result.reviewExceeds?'Der angegebene Kontrollaufwand ist größer als die rechnerisch frei werdende Zeit. Die Netto-Kapazität wird deshalb mit 0 angesetzt.':'Das ist ein Szenario auf Basis Ihrer Angaben, kein nachgewiesener Kundenerfolg. Verfügbare Kapazität ist nicht automatisch eine Geldersparnis.';output.append(note);
       const button=document.createElement('button');button.type='button';button.className='text-link';button.textContent='Berechnung als Text speichern';
       on(button,'click',()=>{
         if(result!==snapshot)return;
         download(`SEVAREL Consulting — Potenzialrechnung\nDatum: ${new Date().toLocaleDateString('de-DE')}\n\nEingaben:\n${Object.entries(inputs).map(([k,v])=>k+': '+v).join('\n')}\n\nNetto-Kapazität: ${number(snapshot.hours)} Stunden/Monat\nKapazitätswert: ${money(snapshot.capacityValue)} pro Monat\nNach laufenden Kosten: ${money(snapshot.netValue)} pro Monat\nKapazitäts-Rücklauf: ${snapshot.payback===null?'nicht positiv':number(snapshot.payback)+' Monate'}\n\nKeine garantierte Zahlungseinsparung. Ergebnisse hängen vollständig von den Annahmen ab.\n`,'sevarel-potenzialrechnung.txt');
       });output.append(button);
     }catch(e){stale();error.textContent=e.message;}
   };
   on(calculator,'input',stale);on(calculator,'change',stale);on(calculator,'reset',()=>queueMicrotask(stale));
   on(calculator,'submit',e=>{e.preventDefault();if(calculator.reportValidity())draw();else stale();});draw();
 }
 const quiz=document.getElementById('process-check');if(quiz){const qs=NovaTools.QUESTIONS;let step=0,values={};const box=document.getElementById('quiz-question'),back=document.getElementById('quiz-back'),next=document.getElementById('quiz-next'),error=document.getElementById('quiz-error'),result=document.getElementById('quiz-result');
 function draw(){error.textContent='';box.replaceChildren();document.getElementById('quiz-counter').textContent=`Frage ${step+1} von ${qs.length}`;document.getElementById('quiz-progress').value=step+1;back.disabled=step===0;next.textContent=step===qs.length-1?'Ergebnis ansehen':'Weiter';const q=qs[step],fieldset=document.createElement('fieldset');fieldset.className='quiz-fieldset';const legend=document.createElement('legend');legend.textContent=q.question;fieldset.append(legend);const opts=document.createElement('div');opts.className='quiz-options';for(const [value,text]of q.options){const label=document.createElement('label');label.className='quiz-option';const radio=document.createElement('input');radio.type='radio';radio.name=q.key;radio.value=value;radio.checked=values[q.key]===value;on(radio,'change',()=>{values[q.key]=value;error.textContent='';});const span=document.createElement('span');span.textContent=text;label.append(radio,span);opts.append(label);}fieldset.append(opts);box.append(fieldset);}
 function finish(){const r=NovaTools.assess(values);quiz.hidden=true;result.hidden=false;result.replaceChildren();const h=document.createElement('h2');h.textContent=r.title;const list=document.createElement('ul');r.reasons.forEach(reason=>{const li=document.createElement('li');li.textContent=reason;list.append(li);});const note=document.createElement('p');note.className='small';note.textContent='Orientierung anhand Ihrer Angaben. Kein validierter Unternehmensscore und keine Verpflichtung, eine Beratung zu kaufen.';const anchor=document.createElement('a');anchor.href=r.url;anchor.className='text-link';anchor.textContent='Passenden Beratungsbereich ansehen';const actions=document.createElement('div');actions.className='result-actions';const save=document.createElement('button');save.type='button';save.className='button button-outline';save.textContent='Ergebnis speichern';on(save,'click',()=>download(`SEVAREL Consulting — KI- & Technik-Check\n\n${r.title}\n${r.reasons.join('\n\n')}\n\nIhre Angaben:\n${r.answers.map(([q,a])=>q+'\n'+a).join('\n\n')}\n\nQualitative Orientierung, keine Eignungsgarantie.\n`,'sevarel-ki-technik-check.txt'));const restart=document.createElement('button');restart.type='button';restart.className='button button-outline';restart.textContent='Neu beginnen';on(restart,'click',()=>{step=0;values={};quiz.hidden=false;result.hidden=true;draw();box.querySelector('input').focus();});actions.append(save,restart);result.append(h,list,note,anchor,actions);result.focus({preventScroll:true});result.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'center'});window.NovaPreview?.rewrite();}
 on(back,'click',()=>{step=Math.max(0,step-1);draw();box.querySelector('input').focus();});on(quiz,'submit',e=>{e.preventDefault();if(!values[qs[step].key]){error.textContent='Bitte wählen Sie eine Antwort.';return;}if(step===qs.length-1){finish();return;}step++;draw();box.querySelector('input').focus();});draw();}
 const form=document.getElementById('contact-form');
 if(form){
   const serviceSelect=document.getElementById('contact-service');
   const formatSelect=document.getElementById('contact-format');
   const formatField=document.getElementById('contact-format-field');
   const status=document.getElementById('contact-status'),output=document.getElementById('contact-output');
   const result=document.getElementById('contact-result'),submit=form.querySelector('[type=submit]');
   const catalog={aliases:window.NOVA_REDIRECTS||{},services:Array.from(serviceSelect.options).map(o=>o.value).filter(Boolean),
     formats:Object.fromEntries(Array.from(formatSelect.options).filter(o=>o.value).map(o=>[o.value,o.textContent])),
     servicePaths:Object.fromEntries(Array.from(serviceSelect.options).filter(o=>o.dataset.servicePath).map(o=>[o.dataset.servicePath,o.value]))};
   catalog.offers=JSON.parse(document.getElementById('contact-offers')?.textContent||'{}');
   const offerInput=document.getElementById('contact-offer'),offerNote=document.getElementById('contact-offer-note'),offerName=document.getElementById('contact-offer-name');
   const errorSummary=document.getElementById('contact-errors'),success=document.getElementById('contact-success');
   form.noValidate=true;
   const params=new URLSearchParams(window.NOVA_PORTABLE?(location.hash.split('?')[1]||''):location.search);
   // Empty params.get('format') is a placeholder, never a workshop selection.
   const initial=NovaContact.prefill(params,catalog);
   serviceSelect.value=initial.service;formatSelect.value=initial.format;offerInput.value=initial.offer||'';
   let busy=false,widgetId=null,token='',submissionKey='',lastPayload='';
   const server=form.dataset.mode==='email'&&!window.NOVA_PORTABLE;
   function syncFields(){
     if(offerInput.value&&catalog.offers[offerInput.value]?.service!==serviceSelect.value)offerInput.value='';
     offerNote.hidden=!offerInput.value;offerInput.disabled=!offerInput.value||busy;offerName.textContent=catalog.offers[offerInput.value]?.name||'';
     const workshops=serviceSelect.value===NovaContact.TRAINING_SERVICE;
     formatField.hidden=!workshops;
     formatSelect.disabled=!workshops||busy;
     if(!workshops){formatSelect.value='';formatSelect.setCustomValidity('');}
   }
   function setStatus(message,isError=false){status.textContent=message;status.classList.toggle('error',isError);}
   function invalidateResult(){
     success.hidden=true;
     const hadResult=!result.hidden||!!output.value;
     result.hidden=true;output.value='';submissionKey='';lastPayload='';
     if(hadResult)setStatus('Angaben geändert. Bitte den Anfragebrief erneut erstellen.');
     else if(!busy)setStatus('');
   }
   function clearValidity(){errorSummary.hidden=true;errorSummary.replaceChildren();for(const el of form.elements){el.setCustomValidity?.('');el.removeAttribute('aria-invalid');const err=document.getElementById(el.id+'-error');if(err)err.remove();if(el.dataset.priorDescription!==undefined){if(el.dataset.priorDescription)el.setAttribute('aria-describedby',el.dataset.priorDescription);else el.removeAttribute('aria-describedby');delete el.dataset.priorDescription;}}}
   function showErrors(errors){clearValidity();const title=document.createElement('h3');title.textContent='Bitte prüfen Sie Ihre Angaben.';const list=document.createElement('ul');errorSummary.append(title,list);for(const [field,message]of Object.entries(errors)){const input=form.elements.namedItem(field);const li=document.createElement('li');if(input&&input.type!=='hidden'&&field!=='website'){input.setAttribute('aria-invalid','true');const hint=document.createElement('span');hint.id=input.id+'-error';hint.className='field-error';hint.textContent=message;input.parentElement.append(hint);input.dataset.priorDescription=input.getAttribute('aria-describedby')||'';input.setAttribute('aria-describedby',[input.dataset.priorDescription,hint.id].filter(Boolean).join(' '));const a=document.createElement('a');a.href='#'+input.id;a.textContent=message;on(a,'click',e=>{e.preventDefault();input.focus();});li.append(a);}else li.textContent=message;list.append(li);}errorSummary.hidden=false;errorSummary.focus();setStatus('Die Anfrage wurde nicht versendet.',true);}
   on(document.getElementById('contact-offer-clear'),'click',()=>{offerInput.value='';syncFields();invalidateResult();});
   on(form,'input',event=>{clearValidity();event.target.setCustomValidity?.('');if(event.target!==output)invalidateResult();});
   on(form,'change',event=>{clearValidity();event.target.setCustomValidity?.('');if(event.target===serviceSelect)offerInput.value='';syncFields();invalidateResult();});
   on(form,'reset',()=>{invalidateResult();clearValidity();queueMicrotask(()=>{if(form.isConnected&&!controller.signal.aborted)syncFields();});});
   on(window,'pageshow',()=>{if(form.isConnected){syncFields();invalidateResult();}});
   syncFields();submit.disabled=false;
   function removeWidget(){if(widgetId!==null&&window.turnstile){try{window.turnstile.remove(widgetId);}catch{}widgetId=null;}token='';}
   const aborted=()=>new DOMException('Seite verlassen','AbortError');
   async function loadSecurity(){
     if(window.turnstile)return;
     await new Promise((resolve,reject)=>{
       const script=document.createElement('script');
       let done=false;
       const finish=error=>{if(done)return;done=true;clearTimeout(timer);controller.signal.removeEventListener('abort',abort);script.onload=script.onerror=null;if(error){script.remove();reject(error);}else resolve();};
       const abort=()=>finish(aborted());
       const timer=setTimeout(()=>finish(Error('Die Sicherheitsprüfung konnte nicht rechtzeitig geladen werden. Bitte erneut versuchen.')),15000);
       script.src='https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';script.async=true;
       script.onload=()=>finish(window.turnstile?null:Error('Die Sicherheitsprüfung ist nicht verfügbar.'));
       script.onerror=()=>finish(Error('Die Sicherheitsprüfung konnte nicht geladen werden.'));
       controller.signal.addEventListener('abort',abort,{once:true});document.head.append(script);
     });
   }
   async function security(){
     if(token)return token;
     if(!form.dataset.sitekey)throw Error('Der Sicherheitsdienst ist noch nicht konfiguriert.');
     setStatus('Bitte die Sicherheitsprüfung im Formular abschließen.');
     await loadSecurity();if(controller.signal.aborted)throw aborted();
     return new Promise((resolve,reject)=>{
       let done=false;
       const finish=(error,value)=>{if(done)return;done=true;clearTimeout(timer);controller.signal.removeEventListener('abort',abort);if(error)reject(error);else resolve(value);};
       const abort=()=>{removeWidget();finish(aborted());};
       const timer=setTimeout(()=>{removeWidget();finish(Error('Die Sicherheitsprüfung ist abgelaufen. Bitte erneut versuchen.'));},120000);
       controller.signal.addEventListener('abort',abort,{once:true});removeWidget();
       try{widgetId=window.turnstile.render('#turnstile-container',{sitekey:form.dataset.sitekey,action:'consulting_contact',
         callback:value=>{token=value;finish(null,value);},
         'error-callback':()=>finish(Error('Die Sicherheitsprüfung ist fehlgeschlagen.')),
         'expired-callback':()=>{token='';finish(Error('Die Sicherheitsprüfung ist abgelaufen. Bitte erneut versuchen.'));}
       });}catch(error){finish(error);}
     });
   }
   disposeContact=removeWidget;
   on(form,'submit',async event=>{
     event.preventDefault();if(busy)return;
     clearValidity();syncFields();
     // Validation and an accessible summary share the same policy as the backend.
     // Disabled conditional inputs are excluded; normalize again before any export or network call.
     const raw=Object.fromEntries(new FormData(form));
     const checked=NovaContact.validate(raw,catalog);
     if(!checked.ok){
       showErrors(checked.errors);
       return;
     }
     const data=checked.value;
     if(!server){output.value=NovaContact.brief(data,catalog);result.hidden=false;setStatus('Anfragebrief erstellt. Es wurde nichts versendet.');return;}
     // Freeze the exact validated request while the security check / delivery is pending.
     const editable=Array.from(form.elements).filter(el=>el.matches('input,select,textarea')&&el!==output);
     const disabledBefore=editable.map(el=>el.disabled);busy=true;submit.disabled=true;editable.forEach(el=>el.disabled=true);
     const fingerprint=JSON.stringify(data);
     let timeout=null;
     try{
       if(fingerprint!==lastPayload||!submissionKey){
         if(typeof crypto.randomUUID==='function')submissionKey=crypto.randomUUID();
         else{const bytes=crypto.getRandomValues(new Uint8Array(16));bytes[6]=(bytes[6]&15)|64;bytes[8]=(bytes[8]&63)|128;const hex=Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');submissionKey=`${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;}
         lastPayload=fingerprint;
       }
       const turnstileToken=await security();if(controller.signal.aborted)return;
       setStatus('Ihre Anfrage wird übermittelt …');
       const requestAbort=new AbortController();
       const relayAbort=()=>requestAbort.abort();controller.signal.addEventListener('abort',relayAbort,{once:true});
       timeout=setTimeout(()=>requestAbort.abort(),35000);
       let response;
       try{response=await fetch('/api/contact',{method:'POST',headers:{'Content-Type':'application/json','Idempotency-Key':submissionKey},body:JSON.stringify({...data,turnstileToken}),signal:requestAbort.signal});}
       finally{controller.signal.removeEventListener('abort',relayAbort);clearTimeout(timeout);}
       let body;try{body=await response.json();}catch{throw Error('Der Empfangsdienst hat keine gültige Antwort geliefert. Ihre Eingaben bleiben erhalten.');}
       if(!response.ok||body.ok!==true)throw Error(body.message||'Die Übermittlung ist fehlgeschlagen. Ihre Eingaben bleiben erhalten.');
       form.reset();
       success.hidden=false;
       document.getElementById('contact-receipt').textContent='Der E-Mail-Dienst hat die Anfrage angenommen.'+(body.reference?' Ihre Referenz: '+body.reference+'.':'')+' Eine Zustellung bis ins Postfach ist damit noch nicht bestätigt.';
       setStatus('Anfrage angenommen. Die Bestätigung steht unter dem Formular.');
       success.focus({preventScroll:true});success.scrollIntoView({behavior:'auto',block:'nearest'});
     }catch(error){
       if(!controller.signal.aborted){setStatus(error.name==='AbortError'?'Zeitüberschreitung: Die Annahme ist nicht bestätigt. Ihre Eingaben bleiben erhalten. Bitte nicht mehrfach sofort absenden.':error.message||'Ihre Anfrage konnte nicht übermittelt werden.',true);output.value=NovaContact.brief(data,catalog);result.hidden=false;}
     }finally{
       clearTimeout(timeout);busy=false;
       editable.forEach((el,i)=>el.disabled=disabledBefore[i]);submit.disabled=false;syncFields();removeWidget();
     }
   });
   on(document.getElementById('download-contact'),'click',()=>{if(!result.hidden&&output.value)download(output.value,'sevarel-beratungsanfrage.txt');});
   on(document.getElementById('copy-contact'),'click',async()=>{
     if(result.hidden||!output.value)return;
     try{await navigator.clipboard.writeText(output.value);setStatus('Anfragebrief kopiert. Es wurde nichts versendet.');}
     catch{output.focus();output.select();setStatus('Bitte den markierten Text manuell kopieren.');}
   });
 }

}
window.NovaUI=Object.freeze({init,dispose:()=>{cleanup();window.NovaGalaxy?.dispose();}});
if(!window.NOVA_PORTABLE){if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();}
})();
