/* Pure, explainable business tools. No company score, prognosis or hidden external call. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.NovaTools=api;})(typeof globalThis==='undefined'?this:globalThis,function(){
'use strict';
const limits={cases:[0,1000000],minutes:[0,480],realization:[0,100],review:[0,10000],rate:[0,10000],recurring:[0,1000000],oneoff:[0,100000000]};
function potential(input){const v={};for(const [key,[min,max]]of Object.entries(limits)){const n=Number(input[key]);if(!['string','number'].includes(typeof input[key])||String(input[key]).trim()===''||!Number.isFinite(n)||n<min||n>max)throw Error('Bitte alle Zahlen innerhalb der angegebenen Grenzen eingeben.');v[key]=n;}
const gross=v.cases*v.minutes/60*v.realization/100;
const hours=Math.max(0,gross-v.review),capacityValue=hours*v.rate,netValue=capacityValue-v.recurring;
return {...v,gross,hours,capacityValue,netValue,annual:netValue*12,payback:netValue>0?v.oneoff/netValue:null,reviewExceeds:gross<v.review};}
const QUESTIONS=[
{key:'goal',question:'Ist die technische Aufgabe konkret beschrieben?',options:[['yes','Ja, mit einem erkennbaren Ergebnis.'],['no','Noch nicht. Wir möchten KI oder andere technische Möglichkeiten zunächst einordnen.']]},
{key:'process',question:'Sind Arbeitsfall, beteiligte Programme und Ausnahmen bekannt?',options:[['yes','Ja, einschließlich Zuständigkeiten und typischer Ausnahmen.'],['no','Nicht vollständig. Unterschiedliche Personen beschreiben ihn anders.']]},
{key:'data',question:'Sind Datenquellen und Zugriffsrechte geklärt?',options:[['yes','Ja, die benötigten Informationen sind verfügbar und freigegeben.'],['no','Teilweise oder noch nicht.']]},
{key:'systems',question:'Ist die passende Software- oder Systemlösung bereits entschieden?',options:[['existing','Wir möchten zunächst vorhandene Anwendungen besser nutzen.'],['choose','Wir müssen zwischen mehreren Systemen oder Entwicklung entscheiden.'],['chosen','Es gibt eine begründete und freigegebene Auswahl.']]},
{key:'ai',question:'Steht bei Ihrem Vorhaben KI im Mittelpunkt?',options:[['yes','Ja, ein beschriebener Anwendungsfall soll geprüft werden.'],['no','Nein oder noch ohne konkreten Anwendungsfall.']]},
{key:'owner',question:'Gibt es Verantwortliche und Zeit für die Veränderung?',options:[['yes','Ja, Entscheidung und Mitwirkung sind organisatorisch geklärt.'],['no','Das muss noch abgestimmt werden.']]}
];
function assess(values){for(const q of QUESTIONS)if(!q.options.some(([v])=>v===values[q.key]))throw Error('Bitte alle sechs Fragen beantworten.');
const reasons=[];let type;
if(values.goal==='no'){type='direction';reasons.push('Das gewünschte Ergebnis ist noch nicht ausreichend eingegrenzt. Die Anwendungsaufgabe sollte vor einer Produkt- oder Modellauswahl geklärt werden.');}
else if(values.process==='no'){type='process';reasons.push('Der Ist-Ablauf und seine Ausnahmen sind noch nicht geklärt. Ein System- und Datenflussbild kann die Grundlage für eine Automatisierung schaffen.');}
else if(values.data==='no'){type='data';reasons.push('Daten und Zugriffsrechte sind noch offen. Diese Voraussetzungen sollten vor einer Automatisierung oder einem KI-Pilot geklärt werden.');}
else if(values.systems==='choose'){type='selection';reasons.push('Sie haben einen beschreibbaren Bedarf, aber noch eine Auswahlentscheidung. Vergleichbare Anforderungen und Testszenarien sind der nächste sinnvolle Schritt.');}
else if(values.ai==='yes'){type='ai';reasons.push('Ein konkreter KI-Anwendungsfall kann eingegrenzt getestet werden. Qualitätskriterien, erlaubte Aktionen und Stop-Regeln gehören vorab in das Pilotkonzept.');}
else{type='delivery';reasons.push('Die grundlegenden Entscheidungen scheinen nach Ihren Angaben weitgehend geklärt. Ein begrenzter Einführungstest mit messbaren Kriterien kann der nächste Schritt sein.');}
if(values.owner==='no')reasons.push('Unabhängig davon fehlen noch geklärte Verantwortliche oder Kapazitäten. Diese organisatorische Voraussetzung hat vor einem breiten Start Vorrang.');
if(values.systems==='existing')reasons.push('Die vorhandenen Systeme sind ausdrücklich eine Option. Ein Neukauf ist aus diesen Angaben nicht automatisch abzuleiten.');
const map={direction:['Zuerst die technische Frage klären',values.ai==='yes'?'/beratung/ki-strategie/':'/beratung/software-programmberatung/'],process:['Zuerst Datenfluss und Systemgrenzen klären','/beratung/automatisierung-integration/'],data:['Zuerst Daten und Rechte klären','/beratung/architektur-infrastruktur/'],selection:['Eine Auswahl fundiert vorbereiten','/beratung/software-programmberatung/'],ai:['Einen begrenzten KI-Pilot vorbereiten','/beratung/ki-strategie/'],delivery:['Die Einführung kontrolliert vorbereiten','/beratung/technische-projektbegleitung/']};
return {type,title:map[type][0],url:map[type][1],reasons,answers:QUESTIONS.map(q=>[q.question,q.options.find(o=>o[0]===values[q.key])[1]])};}
return Object.freeze({potential,assess,QUESTIONS,limits});});
