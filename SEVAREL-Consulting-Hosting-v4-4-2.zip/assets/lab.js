/* SEVAREL Praxislabor: deterministic excerpts, not a language model or authorization service. */
(function(root,factory){'use strict';if(typeof module==='object'&&module.exports)module.exports=factory(require('./content/lab-fixtures.json'));else root.NovaLab=factory(root.NOVA_LAB_DATA);})(typeof globalThis!=='undefined'?globalThis:this,function(data){
 'use strict';
 const normalize=s=>String(s||'').toLowerCase().replaceAll('ä','ae').replaceAll('ö','oe').replaceAll('ü','ue').replaceAll('ß','ss').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9 ]/g,' ').replace(/\s+/g,' ').trim();
 function topics(q){const n=' '+normalize(q)+' ';return data.topics.filter(t=>t.aliases.some(a=>n.includes(' '+normalize(a)+' '))).map(t=>t.id);}
 const reply=(status,message,sources=[])=>({status,message,sources:sources.map(d=>({id:d.id,title:d.title,version:d.version,text:d.text}))});
 function answer(question,role){
  if(!Object.hasOwn(data.roles,role))return reply('abstain','Keine auswertbare Rolle. Bitte einen vorgesehenen Demozugang wählen.');
  const q=normalize(question);
  if(q.length<3)return reply('clarify','Bitte eine konkrete Frage zur Demo stellen.');
  if(String(question).length>300)return reply('clarify','Bitte die Frage auf höchstens 300 Zeichen begrenzen.');
  if(/ignoriere alle regeln|ignore all|system prompt|zeige alle geheimnisse/.test(q))return reply('blocked','Diese Eingabe wird im Demonstrationsmodell nicht als Sachfrage bearbeitet.');
  const candidates=topics(q);
  if(candidates.length>1)return reply('clarify','Die Frage verbindet mehrere Themen. Bitte zuerst eine einzelne Frage stellen.');
  if(!candidates.length)return reply('abstain','Dazu liegt im freigegebenen Demobestand keine passende Quelle vor.');
  // Filter before excerpt generation. This simulation runs client-side with public synthetic data.
  const allowed=data.documents.filter(d=>d.topic===candidates[0]&&d.state==='active'&&d.roles.includes(role));
  if(!allowed.length)return reply('abstain','Dazu liegt im freigegebenen Demobestand keine passende Quelle vor.');
  if(new Set(allowed.map(d=>d.text)).size>1)return reply('conflict','Die gültigen Demoquellen widersprechen sich. Bitte eine zuständige Person um Klärung bitten.',allowed);
  return reply('answer',allowed[0].text,[allowed[0]]);
 }
 function baseline(question){
  const ids=topics(question);const d=data.documents.find(x=>ids.includes(x.topic));
  return d?reply('answer',d.text,[d]):reply('abstain','Keine Quelle gefunden.');
 }
 function evaluate(){
  const rows=data.tests.map(t=>{const controlled=answer(t.question,t.role),simple=baseline(t.question);const matches=x=>x.status===t.expectedStatus&&JSON.stringify(x.sources.map(s=>s.id))===JSON.stringify(t.expectedSources);return {...t,controlled,baseline:simple,pass:matches(controlled),baselinePass:matches(simple)};});
  return {fixtureVersion:data.version,date:data.date,total:rows.length,passed:rows.filter(r=>r.pass).length,baselinePassed:rows.filter(r=>r.baselinePass).length,rows,note:'Handverlesene synthetische Tests für ein festes Regelmodell. Kein LLM-Benchmark, kein Sicherheitsnachweis, keine Kundenmessung.'};
 }
 function mount(on){
  const form=document.getElementById('lab-question-form');if(!form)return;
  const q=document.getElementById('lab-question'),role=document.getElementById('lab-role'),out=document.getElementById('lab-answer');
  const labels={answer:'Belegter Quellenauszug',abstain:'Keine belegbare Antwort',conflict:'Widersprüchliche Quellen',clarify:'Rückfrage erforderlich',blocked:'Nicht als Sachfrage bearbeitet'};
  const el=(tag,text,cls)=>{const x=document.createElement(tag);x.textContent=text;if(cls)x.className=cls;return x;};
  function show(){const r=answer(q.value,role.value);out.replaceChildren(el('span',labels[r.status],'overline'),el('p',r.message));out.dataset.status=r.status;for(const s of r.sources){const item=el('div','','lab-citation');item.append(el('strong',s.id+' · '+s.title+' · Version '+s.version),el('p',s.text));out.append(item);}out.hidden=false;out.focus({preventScroll:true});}
  on(form,'submit',e=>{e.preventDefault();show();});
  document.querySelectorAll('[data-lab-question]').forEach(b=>on(b,'click',()=>{q.value=b.dataset.labQuestion;show();}));
  on(role,'change',()=>{out.hidden=true;out.replaceChildren();});on(q,'input',()=>{out.hidden=true;});
  const result=document.getElementById('lab-tests-status');on(document.getElementById('lab-run-tests'),'click',()=>{const r=evaluate();result.textContent=r.passed+' von '+r.total+' vorgesehenen Fällen im Regelmodell bestanden. Der ungefilterte Vergleich erreicht '+r.baselinePassed+' von '+r.total+'. Diese Werte sind kein Maß für die Qualität eines Sprachmodells.';});
  on(document.getElementById('lab-download-tests'),'click',()=>{const r=evaluate(),blob=new Blob([JSON.stringify(r,null,2)],{type:'application/json;charset=utf-8'}),u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download='SEVAREL-Praxislabor-Testlauf.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1500);});
 }
 return Object.freeze({data,answer,baseline,evaluate,mount});
});
