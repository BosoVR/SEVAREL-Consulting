/* Contact state rules shared by browser, export and generated server validation. */
(function(root,factory){'use strict';const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.NovaContact=api;})(typeof globalThis==='undefined'?this:globalThis,function(){
  'use strict';
  const TRAINING_SERVICE='KI- & Softwareschulungen';
  const LIMITS=Object.freeze({name:120,company:160,email:200,message:4800});
  const own=(obj,key)=>Object.prototype.hasOwnProperty.call(obj||{},key);
  const text=value=>typeof value==='string'?value.trim():'';
  function normalize(data={},catalog={}){
    data=data&&typeof data==='object'&&!Array.isArray(data)?data:{};
    const service=text(data.service);
    const value={name:text(data.name),company:text(data.company),email:text(data.email),service,
      format:service===TRAINING_SERVICE?text(data.format):'',message:text(data.message),website:text(data.website)};
    if(text(data.offer))value.offer=text(data.offer);
    return value;
  }
  function validate(data={},catalog={}){
    data=data&&typeof data==='object'&&!Array.isArray(data)?data:{};
    const value=normalize(data,catalog),errors={};
    if(!value.name||value.name.length>LIMITS.name||/[\r\n]/.test(value.name))errors.name='Bitte einen Namen mit höchstens 120 Zeichen eingeben.';
    if(value.company.length>LIMITS.company||/[\r\n]/.test(value.company))errors.company='Bitte den Unternehmensnamen ohne Zeilenumbrüche und mit höchstens 160 Zeichen eingeben.';
    if(!value.email||value.email.length>LIMITS.email||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.email))errors.email='Bitte eine gültige E-Mail-Adresse eingeben.';
    if(!Array.isArray(catalog.services)||!catalog.services.includes(value.service))errors.service='Bitte ein Thema auswählen. Bei Unsicherheit wählen Sie „Noch offen“.';
    const rawOffer=text(data.offer);
    if(rawOffer&&(!own(catalog.offers,rawOffer)||catalog.offers[rawOffer].service!==value.service))errors.offer='Das Einstiegsangebot passt nicht zum gewählten Thema. Bitte die Auswahl entfernen.';
    const rawFormat=text(data.format);
    if(rawFormat&&value.service!==TRAINING_SERVICE)errors.format='Ein Workshopformat kann nur zum Thema „KI- & Softwareschulungen“ ausgewählt werden.';
    else if(rawFormat&&!own(catalog.formats,rawFormat))errors.format='Bitte ein gültiges Workshopformat auswählen oder die Auswahl offenlassen.';
    if(value.message.length<20||value.message.length>LIMITS.message)errors.message='Bitte die Ausgangslage mit 20 bis 4.800 Zeichen beschreiben. Leerzeichen allein reichen nicht aus.';
    if(value.website)errors.website='Bitte die Angaben prüfen.';
    return {ok:Object.keys(errors).length===0,value,errors};
  }
  /** A non-empty, known URL target is required. The blank placeholder is never a workshop. */
  function prefill(params,catalog={}){
    const rawGet=k=>text(typeof params?.get==='function'?params.get(k):params?.[k]);
    const get=k=>{const v=rawGet(k);return own(catalog.aliases,v)?catalog.aliases[v]:v;};
    const supplied=get('service');
    const pickService=s=>(catalog.services||[]).includes(s)?s:own(catalog.servicePaths,s)?catalog.servicePaths[s]:'';
    let service=pickService(supplied),format='';const target=get('format');
    // A deliberately supplied but invalid service must not silently turn into Workshops.
    if(supplied&&!service)return {service:'',format:''};
    if(target&&own(catalog.formats,target)){
      if(!supplied||service===TRAINING_SERVICE){service=TRAINING_SERVICE;format=target;}
    }else if(!supplied&&target&&own(catalog.servicePaths,target))service=catalog.servicePaths[target];
    const offer=rawGet('angebot');
    if(offer&&own(catalog.offers,offer)&&!format&&(!supplied||service===catalog.offers[offer].service))return {service:catalog.offers[offer].service,format:'',offer};
    return {service,format};
  }
  function brief(data,catalog={}){
    const value=normalize(data,catalog),v=validate(value,catalog);
    if(!v.ok)throw new Error(Object.values(v.errors)[0]);
    const lines=['BERATUNGSANFRAGE — SEVAREL CONSULTING','',`Name: ${value.name}`,`Unternehmen: ${value.company||'Nicht angegeben'}`,`E-Mail: ${value.email}`,`Thema: ${value.service}`];
    if(value.offer)lines.push(`Einstiegsangebot: ${catalog.offers[value.offer].name}`);
    if(value.service===TRAINING_SERVICE)lines.push(`Workshopformat: ${value.format?catalog.formats[value.format]:'Noch offen — bitte gemeinsam auswählen'}`);
    lines.push('',value.message,'','Diese Anfrage ist keine Bestellung.');
    return lines.join('\n')+'\n';
  }
  return Object.freeze({TRAINING_SERVICE,LIMITS,normalize,validate,prefill,brief});
});
